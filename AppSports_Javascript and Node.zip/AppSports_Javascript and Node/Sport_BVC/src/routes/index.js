const { Router } = require('express');
const router = Router();
const fs = require('fs');
//const user_event = [];

//Read the file json to save the initial data to not overwrite
const json_user = fs.readFileSync('../user_event.json', 'utf-8');
const user_event = JSON.parse(json_user);

router.get('/', (req, res) => {
    //res.send('Hello World')
    res.render('index.ejs', {
        user_event
    })
});

router.get('/new-entry', (req, res) => {
    res.render('new-entry');
})

router.post('/new-entry', (req, res) => {
    const { id, name, address, status } = req.body;
    if (!id || !name || !address || !status){
            res.status(400).send('The entries must be a value');
            return;
         }

    let newUser = {
        id,
        name,
        address,
        status
    }

    //To show info's user in welcome page, in this case in jason format
    router.get('/welcome', (req, res) => {
        res.json(newUser);
        //res.send('received');
      })
    
    //Add new user to array
    user_event.push(newUser);

    //convert the array in jason format and then create a jason file.
    const jason_user = JSON.stringify(user_event);
    fs.writeFileSync('../user_event.json', jason_user, 'utf-8');

    //Read again the file to show in page new-entry
    var data = fs.readFileSync('../user_event.json', 'utf-8');
    res.send(data);
    //res.send('received');   
  
});

module.exports = router;





