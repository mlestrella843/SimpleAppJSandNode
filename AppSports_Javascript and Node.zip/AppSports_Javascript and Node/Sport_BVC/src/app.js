

const express = require('express');
const app = express();
const path = require('path');
const morgan = require('morgan');


//settingd servers
app.set('port', 5000);
app.set('views', path.join( __dirname, 'views'));
app.set('view engine', 'ejs');

//midlewares
app.use(morgan('dev'));
app.use(express.urlencoded( {extended:false} ));

//routes
app.use(require('./routes/index'));

//Static
//app.use(express.static(path.join(__dirname, 'public')));
// 404 handler

app.use((req, res, next) => {
    res.status(404).send('404 Not FOund');
});

module.exports = app;










/*


function addUser() {   

    var id, fullname, addres, status;

        var user = new jsObject(id, fullname, address, status);
        user.id = $("#id").val();
        user.fullname = $("#full_name").val();
        user.address = $("#address").val();
        user.status = $("#status").val();

       console.log(user);

		if (isNaN(id)) {
			alert("you entered a letters, please fill with numbers");
			//return false;
		} else if (id == "") {
			alert("ID must be filled out");
		//	return false;
        }
		if (fullname == "") {
			alert("Name must be filled and a valid character");
			//return false;
		} else if (fullname == "") {
			alert("Name must be filled out");
			//return false;
		}
		if (address == "") {
			alert("Address must be filled out");
			//return false;
		}
        /*
        console.log("Este es el nombre: ", fullname);
        console.log("Esta es la direccion: ", address);
        console.log("Esta es el Status: ", status); 

        //console.log(user);

        
       let array = []; 
        array[0] = user;
        console.log("Esto prueba el arreglo", array[0]);



        function jsObject(id, fullname, address, status){
                this.id = id;
                this.fullname = fullname;
                this.address = address;
                this.status = status;
            }
 };

 */





